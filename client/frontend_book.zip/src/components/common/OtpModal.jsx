import React, { useState } from 'react';
import axios from 'axios';

const OtpModal = ({ isOpen, email, onClose, onSuccess }) => {
  const [otp, setOtp] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleOtpSubmit = async () => {
    setError('');
    if (!/^\d{4}$/.test(otp)) {
      setError('OTP must be a 4-digit number.');
      return;
    }

    setLoading(true);
    try {
      const response = await axios.post(`${import.meta.env.VITE_API_URL}/verify-otp`, {
        email,
        otp,
      });

      if (response.status === 200) {
        onSuccess();
      } else {
        setError('Invalid OTP. Please try again.');
      }
    } catch (err) {
      if (err.response?.data?.error) {
        setError(err.response.data.error);
      } else {
        setError('An unexpected error occurred. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50">
      <div className="bg-gray-800 p-6 rounded w-full max-w-sm shadow-lg">
        <h2 className="text-white text-lg font-bold mb-4 text-center">Enter OTP</h2>
        <input
          type="text"
          maxLength={4}
          value={otp}
          onChange={(e) => setOtp(e.target.value)}
          className="w-full px-3 py-2 text-center text-xl tracking-widest bg-gray-700 text-white rounded focus:outline-none mb-3"
          placeholder="4-digit code"
        />
        {error && <p className="text-red-500 text-sm text-center">{error}</p>}
        <div className="flex justify-between mt-4">
          <button
            onClick={handleOtpSubmit}
            disabled={loading}
            className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded w-full mr-2"
          >
            {loading ? 'Verifying...' : 'Verify'}
          </button>
          <button
            onClick={onClose}
            className="bg-gray-600 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded w-full ml-2"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default OtpModal;
